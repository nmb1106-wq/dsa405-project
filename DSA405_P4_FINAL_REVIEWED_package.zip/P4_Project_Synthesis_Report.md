# P4: Project Synthesis — Risk Disclosures and Stock Returns

**DSA 405 | Fall 2026 | Unity ID: nmbrockm**

## 1. Data motivation

I wanted to know whether companies that expand their Item 1A risk-factor sections in annual 10-K filings tend to have lower stock returns in the following 12 months. I picked this question because I am interested in finance and whether company disclosures tell investors something useful. At first, I planned a broader S&P 500 study using Stooq prices. Once I started collecting actual data, I narrowed the project to five companies and switched to historical daily prices downloaded through my university's WRDS access to CRSP. My question also became more specific: in this small pilot, is the association consistent, or does it depend on a few unusual filings?

## 2. Sources, provenance, and terms

**Wikipedia S&P 500 constituent table.** I accessed the public HTML table of current S&P 500 securities with pandas for ticker, company, sector, and CIK identifiers. The P2 snapshot contained 503 securities and eight fields. Wikipedia content is generally CC BY-SA, with attribution and applicable page terms. The snapshot is not historical index membership, which creates a possible survivorship-bias problem. Source: https://en.wikipedia.org/wiki/List_of_S%26P_500_companies

**SEC EDGAR.** The U.S. Securities and Exchange Commission publishes company 10-K annual reports. EDGAR means Electronic Data Gathering, Analysis, and Retrieval; CIK means Central Index Key, the SEC's filer identifier. Item 1A contains the company's risk-factor discussion. I used SEC submissions metadata and filing documents, with a contact-identifying request header, caching, error handling, and delays. These public government filings remain subject to SEC fair-access requirements. Filing year here means calendar year submitted, not necessarily fiscal year. Sources: https://www.sec.gov/edgar and https://data.sec.gov/submissions/

**WRDS / CRSP daily stock data.** I downloaded licensed historical CRSP Stock Version 2 (CIZ) daily security records through NC State's Wharton Research Data Services access, covering January 2019 through December 2025 for AAPL, ABT, A, ABBV, and ABNB. The WRDS query selected PERMNO, ticker, daily calendar date, daily price, daily total return, and a daily price adjustment factor. The cleaned file used in my notebook has 8,310 ticker/date observations and `ticker`, `date`, `adjusted_close` fields. The notebook's return calculation uses split-adjusted **price returns**, not dividend-inclusive total returns. CRSP is proprietary/licensed: the raw export and derived daily-price file should not be placed in a public repository without permission. An authorized user needs to obtain their own copy. Source: https://wrds-www.wharton.upenn.edu/ and CRSP documentation available through WRDS.

## 3. Data dictionary and metadata

The cleaned P2 constituent table has one row per **security**: `symbol` (ticker), `security` (name), `gics_sector` and `gics_sub_industry` (categories), `headquarters_location` (text), `date_added` (date), `cik` (10-character text SEC identifier), and `founded` (text). The P3 SEC dataset has one row per **CIK and filing year**, including `CIK`, `ticker`, `filing_year`, `filing_date`, `accession`, `filing_url`, `risk_words` (estimated Item 1A word count), and `extraction_status` (review flag).

The integrated dataset adds `prior_year`, `prior_words`, and `risk_change_pct` (percentage change from the preceding consecutive filing year), plus `target_start`, `target_end`, matched price dates, start and end prices, `return_12m_pct` (split-adjusted 12-month price return in percent), `return_type`, and `price_match_status`. The cleaned CRSP input has `ticker` (text), `date` (trading date), and `adjusted_close` (split-adjusted daily price, not dividend-inclusive). Missing risk changes in the first observed year of each company are left missing rather than set to zero. The final analysis uses 23 complete paired observations from 28 filings.

## 4. Data cleaning steps

In P2, I standardized the eight Wikipedia columns to snake_case, converted `date_added` to a date, kept `cik` as zero-padded text, and preserved `founded` as text. I checked 503 source rows for missing values and exact duplicates. I kept legitimate repeated CIKs for different share classes; the 503 securities were not reduced during P2 cleaning.

In P3, I selected one company per CIK for the pilot, retrieved 10-K metadata, and kept one filing per CIK/filing calendar year. I downloaded filing documents and estimated Item 1A word counts by finding text between the risk-factor heading and the following section. Because layouts vary, these counts are flagged `heuristic_check_required` rather than treated as fully manually validated. I reviewed the boundaries of Airbnb's 2024 Item 1A in the original filing. I calculated `risk_change_pct` only when the previous filing year was consecutive and the two word counts were usable.

For prices, I converted the WRDS daily data into a consistently named CSV and used split-adjusted prices for the notebook's price-return formula. I checked for duplicate security/date records. Airbnb has fewer daily rows because it began trading in late 2020. I did not fill nonexistent historical trading days with fabricated prices. The price conversion should be independently checked against CRSP adjustment-factor documentation before relying on the exact return levels.

## 5. Integration and verification

I connected the current constituent identifiers to SEC filings using CIK, then used ticker and dates to attach daily prices. The SEC table has one row per company/filing year. The notebook finds the first trading price on or after the filing date and the first trading price on or after its 12-month anniversary, allowing up to a seven-day match gap. It calculates `return_12m_pct = (end_price / start_price - 1) × 100`. This is a price return and excludes dividends. Because the SEC filing date can precede public release time or market close, a stricter future study should start at the next eligible trading session to eliminate any same-day timing ambiguity.

The executed P3 notebook loaded **8,310** daily prices and retained **28 of 28** SEC filing records. All 28 received a 12-month return, and **23** had both a consecutive-year risk change and a return. Its verification suite printed **“PASS: risk checks and returns join checks.”** I checked unique CIK/year keys, positive available word counts, year ranges, and join behavior. A deliberate duplicate-row test was used to check that the uniqueness assertion can detect a fan-out problem. A successful assertion does not prove that every Item 1A word count is accurate, so the extraction remains a limitation.

## 6. Findings and uncertainty

The main analysis included **23 complete company-year pairs**. The average year-over-year risk-factor length change was **+7.16%** (median +4.55%), and the average subsequent 12-month split-adjusted stock-price return was **+10.59%** (median +9.34%). Price returns ranged from **−20.35% to +40.14%**. Risk-factor changes ranged from **−4.18% to +78.22%**.

With all 23 observations, the Pearson correlation between risk-factor length changes and later price returns was **−0.236**, a weak negative association. However, Abbott's **2022** filing was an unusually large risk-length increase (**+78.22%**) followed by a **−11.25%** 12-month price return. When I excluded that one observation as a sensitivity check, the correlation became **+0.184** across the remaining **22** observations. The sign flipped, even though both correlations were weak. This means the direction of the association is **not robust to this one observation**. I kept the Abbott record in the main results because it is not automatically an error; the exclusion is only a diagnostic.

My conclusion is not that more risk disclosure predicts worse returns. The sample is small, the extraction is heuristic, and the correlation changes direction when one unusual record is removed. The data show a weak, unstable association, not causation or a reliable investment signal. I would want to manually verify the Abbott Item 1A extraction, expand the sample, and test more companies before making a stronger claim.

## 7. Who or what is missing

The pilot covers only five companies (ABT, AAPL, A, ABBV, ABNB), so nearly all S&P 500 companies, many sectors, smaller non-index firms, and firms that left the index are missing. Using a current constituent list instead of historical membership can introduce survivorship bias. I only examined filings submitted during 2019–2024 and prices through 2025, so earlier recessions and later market conditions are not represented. Airbnb's trading history starts in 2020, limiting earlier observations. The first filing for each company cannot produce a year-over-year change, which reduces 28 filing records to 23 complete pairs.

The dataset also does not capture the *meaning* or seriousness of each risk disclosure, only an estimated word count. Other influences on returns—earnings, interest rates, company events, and broader market moves—are not controlled for. The sample cannot answer whether a change in risk disclosure **causes** a change in returns, or whether investors could have earned excess returns from a trading strategy based on these disclosures.

## 8. AI use log and reflection

I used ChatGPT to help me troubleshoot Python and Colab, understand WRDS query settings, organize my cleaning and merge checks, and draft clearer explanations for the report. I checked its suggestions against actual notebook output instead of assuming that generated code had worked. For example, an earlier AI-assisted draft described the return analysis as unfinished because the CSV was missing. Once I downloaded CRSP data, uploaded the cleaned file into Colab, and reran the cells, that statement became wrong; the saved output showed 8,310 price records and a successful join. I corrected the report to reflect the executed results.

Another important surprise came from checking the correlation. The first result, −0.236, might have led me to describe a negative relationship. Testing the unusually large Abbott 2022 observation changed the correlation to +0.184. That made me realize that a single number without a sensitivity check can be misleading. AI helped me write and debug the workflow, but I was responsible for running it, checking the outputs, and not overstating what the data show.

## 9. Reproducibility

**Repository:** https://github.com/nmb1106-wq/dsa405-project — **verify this is the actual repository URL and push the final files before submission**. A reader should clone the repo, install the dependencies from `requirements.txt`, open the notebook from the repo root, and run its cells from top to bottom. The notebook downloads/caches Wikipedia and SEC content, constructs risk-factor counts, and joins prices if `data/raw/approved_daily_prices.csv` exists. The input must have `ticker,date,adjusted_close` and should cover 2019–2025 for the five pilot tickers. The price file must be obtained separately through authorized WRDS/CRSP access; **do not commit licensed daily prices to a public GitHub repository**. Also avoid committing API credentials, private tokens, or personal account data.

The output should reproduce 28 SEC filings, 8,310 daily-price records, 23 complete pairs, and correlations close to −0.236 (all pairs) and +0.184 (excluding Abbott 2022), assuming the same filing snapshot and CRSP price conversion. The SEC/Wikipedia sources can change, and the exact price-adjustment transformation needs a documented verification. I have not independently confirmed a fresh-kernel run of the entire packaged P4 notebook or verified the live GitHub contents; those are required final checks.

## P4 self-scored rubric (provisional; 0–4 per criterion)

| Criterion | Weight | Self-score | Reason |
|---|---:|---:|---|
| Findings & interpretation | ×2 | 4 | Reports actual results and outlier sensitivity without claiming causation |
| Narrative coherence | ×2 | 4 | Explains question, method, result, and why the conclusion changed |
| Who is missing | ×2 | 4 | Identifies concrete exclusions and their consequences |
| AI use log & reflection | ×2 | 4 | Describes a specific outdated AI-assisted conclusion and how outputs corrected it |
| Technical ambition | ×2 | 3 | SEC parsing, CRSP conversion, temporal join, and validation; more manual checks needed |
| Repository & reproducibility | ×2 | 2 | Instructions exist, but licensed price input and full clean run still require confirmation |
| Documentation carried forward | ×1 | 4 | Updates provenance, dictionary, and cleaning narrative |

**Provisional weighted score: 46/52.** This is a self-assessment, not an instructor grade. Repository verification, price-factor validation, and a clean restart-and-run could change it.

## Appendix A. Full P2 cleaning log (carried forward)

This is the cleaning log from my P2 source. Counts describe the 503-row constituent snapshot, not the later 28-row SEC pilot.

| Step | What I did | Amount checked or changed | Why / what would be lost |
|---|---|---|---|
| 1 | Renamed the eight columns to snake_case | 8 names | Easier code; only the old formatting of names changed |
| 2 | Converted `date_added` to a date | 503 cells | Valid date comparisons; only text formatting changed |
| 3 | Treated `cik` as text | 503 cells | It is an identifier, not a number; no identifier data lost |
| 4 | Added leading zeroes to CIKs | 503 cells | Standard ten-character SEC identifiers; no information lost |
| 5 | Converted `gics_sector` to category | 503 cells | 11 observed sectors; labels unchanged |
| 6 | Converted `gics_sub_industry` to category | 503 cells | Repeated classification labels; values unchanged |
| 7 | Converted four text fields to string type | 2,012 cells | Explicit text types; original values unchanged |
| 8 | Kept legitimate repeated CIKs | 6 rows reviewed, 0 removed | Different share classes; dropping them would lose securities |
| 9 | Kept `founded` as text | 503 values reviewed, 0 rewritten | Numeric conversion could lose founding-history details |
| 10 | Kept all records after checks | 503 reviewed, 0 removed | No invalid rows found; no observations lost |

## Appendix B. Field-level dictionary for the final analysis

| Field | Type / units | Meaning and validation |
|---|---|---|
| `symbol` | text | P2 ticker; unique per security in the 503-row snapshot |
| `security` | text | Company/security name |
| `gics_sector` | category | Broad industry grouping; 11 observed levels in P2 |
| `gics_sub_industry` | category | Detailed industry grouping; 126 observed levels in P2 |
| `headquarters_location` | text | Headquarters description from source |
| `date_added` | date | Date added to the index |
| `cik` / `CIK` | text, ten digits | SEC registrant identifier; not a measured quantity |
| `founded` | text | Year or narrative history, not necessarily a single number |
| `ticker` | text | One ticker chosen per CIK for the pilot; not a unique company identifier |
| `filing_year` | integer year | Calendar year in which the filing was submitted |
| `filing_date` | date | Date the SEC filing was submitted |
| `accession` | text | SEC identifier for a particular filing |
| `filing_url` | URL | Link back to the primary 10-K document |
| `risk_words` | integer word count, nullable | Estimated length of extracted Item 1A; missing means no trusted extraction |
| `extraction_status` | text category | Whether an extraction needs checking or failed |
| `prior_year` | integer year, nullable | Prior available filing year for the same company |
| `prior_words` | integer count, nullable | Previous available Item 1A estimate |
| `risk_change_pct` | percentage, nullable | Year-over-year change; only consecutive years with usable counts |
| `target_start` / `target_end` | dates | Filing date and date 12 months later, respectively |
| `return_12m_pct` | percentage, nullable | Twelve-month price return, **available in the latest executed P3 notebook** |
| `return_type` | text | Whether returns use adjusted or unadjusted closing prices |
| `price_match_status` | text | Indicates whether both needed price observations were found |

**Missingness note:** The P2 snapshot had no missing values. The filing-level fields may be missing when the SEC document could not be parsed, when there was no consecutive earlier year, or when historical prices were unavailable. I did not replace missing values with zero.

## Appendix C. Checks I used and what is still pending

| Check | Evidence / status |
|---|---|
| P2 row accounting | 503 raw rows and 503 cleaned rows, as shown in P2 |
| Duplicate ticker and exact-row checks | Both zero in the P2 audit |
| SEC request failure behavior | Saved P3 notebook demonstrates a simulated HTTP 503 stopping acquisition |
| CIK / filing-year uniqueness | Assertion passed in saved P3 notebook |
| Valid extracted word counts | Positive-value assertion passed for nonmissing values in saved P3 notebook |
| Year window and pilot CIKs | Assertions passed in saved P3 notebook |
| Fan-out rejection | P3 toy-data test passed; P4 adds a test using a duplicated actual risk row, **not yet rerun** |
| Stock-price join and its row count | **Passed in latest P3 run:** 28 joined records and 28 matched returns |
| Manual verification of SEC Item 1A boundaries | **Partially completed:** Airbnb 2024 boundaries reviewed; broader spot-checks needed |
| Fresh kernel, full run, saved outputs | **Still needed**; a full restart-and-run of the packaged notebook has not been verified |

## Appendix D. What I would do next

I would manually validate more Item 1A sections, especially Abbott 2022, independently check the CRSP split-adjustment conversion, verify the repo with a fresh-kernel run, and then expand beyond five companies using historical index membership.
