Place authorized approved_daily_prices.csv here locally. Do not publish licensed CRSP daily data.
